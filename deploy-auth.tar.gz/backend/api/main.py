from fastapi import FastAPI, HTTPException, Depends
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from typing import List, Optional
from datetime import datetime, timedelta
import os
from dotenv import load_dotenv

# Import our modules
import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from database.db_manager_supabase import DatabaseManager
from api.auth import router as auth_router

load_dotenv()

app = FastAPI(
    title="MobiMEA Intelligence Platform API",
    description="Live phone price tracking and market intelligence for Mauritius",
    version="1.0.0"
)

# CORS middleware - allow frontend to connect
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",
        "http://localhost:5174",
        "http://localhost:5175",
        "http://localhost:5176",
        "http://localhost:5177",
        "http://13.214.194.115",
        "http://intel.mobimea.com",
        "https://intel.mobimea.com",
        os.getenv("FRONTEND_URL", "http://localhost:5177")
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize database manager
db_manager = DatabaseManager()

# Include authentication router
app.include_router(auth_router)

@app.get("/")
async def root():
    """API health check"""
    return {
        "message": "MobiMEA Intelligence Platform API",
        "version": "1.0.0",
        "status": "online"
    }

@app.get("/api/health")
async def health_check():
    """Detailed health check"""
    try:
        stats = db_manager.get_dashboard_stats()
        return {
            "status": "healthy",
            "database": "connected",
            "last_scrape": stats.get('last_scrape_time'),
            "timestamp": datetime.utcnow().isoformat()
        }
    except Exception as e:
        raise HTTPException(status_code=503, detail=f"Service unhealthy: {str(e)}")

# ========================================
# DASHBOARD ENDPOINTS
# ========================================

@app.get("/api/dashboard/stats")
async def get_dashboard_stats():
    """Get overall statistics for CEO dashboard"""
    try:
        stats = db_manager.get_dashboard_stats()
        return stats
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/dashboard/latest-prices")
async def get_latest_prices(limit: int = 50):
    """Get latest prices across all products and retailers"""
    try:
        prices = db_manager.get_latest_prices(limit=limit)
        return {
            "count": len(prices),
            "prices": prices
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# ========================================
# PRODUCT ENDPOINTS
# ========================================

@app.get("/api/products")
async def list_all_products(limit: int = 100, brand: Optional[str] = None):
    """List all products with their basic info and specifications"""
    try:
        prices = db_manager.get_latest_prices(limit=limit)

        # Get unique products (group by product_id)
        products_dict = {}
        for price in prices:
            product_id = price['product_id']
            if brand and price['brand'].lower() != brand.lower():
                continue

            if product_id not in products_dict:
                products_dict[product_id] = {
                    'id': product_id,
                    'name': price['product_name'],
                    'brand': price['brand'],
                    'model': price['model'],
                    'slug': price['slug'],
                    'best_price': price['price_cash'],
                    'retailer': price['retailer_name'],
                    'in_stock': price['in_stock'],
                    'url': price.get('url')
                }

        products = list(products_dict.values())
        return {
            'count': len(products),
            'products': products
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/products/{slug}")
async def get_product_details(slug: str):
    """Get detailed product information with all retailer prices"""
    try:
        product = db_manager.get_product_by_slug(slug)

        if not product:
            raise HTTPException(status_code=404, detail="Product not found")

        return product
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/products/{slug}/best-price")
async def get_best_price(slug: str):
    """Get the best current price for a product"""
    try:
        product = db_manager.get_product_by_slug(slug)

        if not product:
            raise HTTPException(status_code=404, detail="Product not found")

        # Find best price (lowest price that's in stock)
        in_stock_prices = [p for p in product['prices'] if p['in_stock'] and p['price']]

        if not in_stock_prices:
            # No in-stock prices, show all prices
            all_prices = [p for p in product['prices'] if p['price']]
            best_price = min(all_prices, key=lambda x: x['price']) if all_prices else None
        else:
            best_price = min(in_stock_prices, key=lambda x: x['price'])

        return {
            "product": {
                "name": product['name'],
                "brand": product['brand'],
                "model": product['model'],
                "variant": product['variant'],
                "slug": product['slug']
            },
            "best_price": best_price,
            "all_prices": product['prices']
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# ========================================
# PRICE HISTORY ENDPOINTS
# ========================================

@app.get("/api/products/{slug}/price-history")
async def get_price_history(slug: str, days: int = 30, retailer: Optional[str] = None):
    """Get price history for a product"""
    try:
        # TODO: Implement with Supabase - returning empty for now
        return {
            'product_slug': slug,
            'days': days,
            'retailer_filter': retailer,
            'history': [],
            'statistics': None
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# ========================================
# PROMOTIONS ENDPOINTS
# ========================================

@app.get("/api/promotions/active")
async def get_active_promotions(brand: Optional[str] = None, retailer: Optional[str] = None):
    """Get all active promotions"""
    try:
        # TODO: Implement with Supabase - returning empty for now
        return {
            'count': 0,
            'promotions': []
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# ========================================
# MARKET INTELLIGENCE ENDPOINTS
# ========================================

@app.get("/api/market/brand-comparison")
async def get_brand_comparison():
    """Compare average prices across brands"""
    try:
        result = db_manager.get_brand_comparison()
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/market/retailer-comparison")
async def get_retailer_comparison():
    """Compare retailers by product count and pricing"""
    try:
        # TODO: Implement with Supabase - returning empty for now
        return {
            'retailers': []
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# ========================================
# SCRAPER STATUS ENDPOINTS
# ========================================

@app.get("/api/scrapers/logs")
async def get_scraper_logs(limit: int = 50):
    """Get recent scraper execution logs"""
    try:
        result = db_manager.get_scraper_logs(limit=limit)
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# ========================================
# LIVE PRICING FOR COMPARISON TOOL
# ========================================

@app.get("/api/phones/live-price/{phone_model}")
async def get_live_price_for_phone(phone_model: str):
    """
    Get live retailer prices for a specific phone model
    Example: /api/phones/live-price/samsung-galaxy-s24
    """
    try:
        # Search for products matching this phone model
        # We'll look for partial matches in the product names
        model_query = phone_model.replace('-', ' ').lower()

        latest_prices = db_manager.get_latest_prices(limit=500)

        # Filter to find matching products
        matching_products = []
        for price in latest_prices:
            product_name_lower = price['product_name'].lower()
            model_lower = price['model'].lower() if price['model'] else ''

            # Check if model matches
            if model_query in product_name_lower or model_query in model_lower:
                matching_products.append(price)

        # Group by variant and find best prices
        if not matching_products:
            return {
                'phone_model': phone_model,
                'found': False,
                'prices': []
            }

        # Get best price (lowest)
        best_price = min(matching_products, key=lambda x: x['price_cash'] if x['price_cash'] else float('inf'))

        return {
            'phone_model': phone_model,
            'found': True,
            'best_price': {
                'retailer': best_price['retailer_name'],
                'price': best_price['price_cash'],
                'original_price': best_price['original_price'],
                'url': best_price['url'],
                'in_stock': best_price['in_stock']
            },
            'all_retailers': matching_products
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    import uvicorn
    port = int(os.getenv("PORT", 8000))
    uvicorn.run(app, host="0.0.0.0", port=port)
